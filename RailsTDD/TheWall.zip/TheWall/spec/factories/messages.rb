FactoryGirl.define do
  factory :message do
    content "MyText"
    user nil
  end
end
