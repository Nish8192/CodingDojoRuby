require 'rails_helper'

RSpec.describe MessagesController, type: :controller do

end
