FactoryGirl.define do
  factory :lender do
    first_name "MyString"
    last_name "MyString"
    email "MyString"
    password ""
    money 1
  end
end
