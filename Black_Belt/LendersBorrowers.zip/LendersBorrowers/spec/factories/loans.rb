FactoryGirl.define do
  factory :loan do
    lender nil
    borrower nil
    amount 1
  end
end
