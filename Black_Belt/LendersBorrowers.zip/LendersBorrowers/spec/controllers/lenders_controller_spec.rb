require 'rails_helper'

RSpec.describe LendersController, type: :controller do

end
