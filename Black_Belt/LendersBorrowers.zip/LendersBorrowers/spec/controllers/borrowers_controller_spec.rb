require 'rails_helper'

RSpec.describe BorrowersController, type: :controller do

end
