require 'rails_helper'

RSpec.describe LoansController, type: :controller do

end
