FactoryGirl.define do
  factory :network do
    user_id 1
    friend_id 1
  end
end
