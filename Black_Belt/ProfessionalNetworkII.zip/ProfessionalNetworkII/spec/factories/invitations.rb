FactoryGirl.define do
  factory :invitation do
    user_id 1
    sender_id 1
  end
end
