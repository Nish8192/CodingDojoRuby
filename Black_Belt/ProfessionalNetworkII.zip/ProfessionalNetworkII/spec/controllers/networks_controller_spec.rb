require 'rails_helper'

RSpec.describe NetworksController, type: :controller do

end
