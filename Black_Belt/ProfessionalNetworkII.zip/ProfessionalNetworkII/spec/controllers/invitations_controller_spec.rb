require 'rails_helper'

RSpec.describe InvitationsController, type: :controller do

end
