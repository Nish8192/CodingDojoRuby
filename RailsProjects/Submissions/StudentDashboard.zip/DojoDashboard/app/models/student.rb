class Student < ApplicationRecord
    EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  belongs_to :dojo
  validates :email, uniqueness: { case_sensitive:false }, format: { with: EMAIL_REGEX}
end
