require_relative 'HumanI'

class Samurai < Human
    @@NumSamurais
    def initialize(health = 200)
        super
        @health = 200
        @@NumSamurais += 1
    end

    def death_blow(obj)
        if obj.class.ancestors.include?(Human)
            obj.health = 0
            return true
        end
        false
    end

    def meditate
        @health = 200
        self
    end

    def how_many
        puts "There are #{@@NumSamurais} samurais murdering things!"
        self
    end
end
