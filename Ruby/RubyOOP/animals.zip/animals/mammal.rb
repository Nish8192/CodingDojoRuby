class Mammal

    def initialize health=150
        @health = health
    end

    def display_health
        puts @health
    end

end
